
public class Videospiel implements Medium {
    /**
     * Die system des Videospiels
     */
    private String _system;

    /**
     * Die system des Videospiels
     */
    // private int _spiellaenge;

    /**
     * Ein Kommentar zum Medium
     */
    private String _kommentar;

    /**
     * Der Titel des Mediums
     * 
     */
    private String _titel;

    /**
     * Initialisiert ein neues Exemplar.
     * 
     * @param titel Der Titel des Videospiel
     * @param kommentar Ein Kommentar zu der Videospiel
     * @param system Der system der Videospiel
     * @param spiellaenge Die Spiellaenge der Videospiel in Minuten
     * 
     * @require titel != null
     * @require kommentar != null
     * @require system != null
     * @require spiellaenge > 0
     * 
     * @ensure getTitel() == titel
     * @ensure getKommentar() == kommentar
     * @ensure getsystem() == system
     * @ensure getSpiellaenge() == spiellaenge
     */
    public Videospiel(String titel, String kommentar, String system)
    {
        assert titel != null : "Vorbedingung verletzt: titel != null";
        assert kommentar != null : "Vorbedingung verletzt: kommentar != null";
        assert system != null : "Vorbedingung verletzt: system != null";
 
        _titel = titel;
        _kommentar = kommentar;
        _system = system;
    }

    /**
     * Gibt Die system der Videospiel zurück.
     * 
     * @return Die system des Videospiels.
     * 
     * @ensure result != null
     */
    public String getsystem()
    {
        return _system;
    }

    @Override
    public String getMedienBezeichnung()
    {
        return "Videospiel";
    }


    @Override
    public String getKommentar()
    {
        return _kommentar;
    }

    @Override
    public String getTitel()
    {
        return _titel;
    }

}